import React from "react";

function App() {
  return (
    <main style={{ padding: 20, fontFamily: "Arial" }}>
      <h1>SC Servicios Integrales</h1>
      <p>Bienvenido a tu app funcional.</p>
    </main>
  );
}

export default App;
